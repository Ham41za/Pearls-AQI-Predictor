
import streamlit as st
import pandas as pd
import numpy as np
import requests
import os
import json
import joblib
import plotly.graph_objects as go
import plotly.express as px


# =================================================================
# PAGE CONFIGURATION
# =================================================================

st.set_page_config(

    page_title="Pearls AQI Predictor",

    page_icon="🌍",

    layout="wide",

    initial_sidebar_state="expanded"

)


# =================================================================
# CUSTOM CSS
# =================================================================

st.markdown("""
<style>

.main-title {

    font-size: 42px;

    font-weight: 700;

    text-align: center;

    margin-bottom: 5px;

}

.subtitle {

    text-align: center;

    font-size: 18px;

    margin-bottom: 30px;

}

.aqi-card {

    padding: 25px;

    border-radius: 15px;

    text-align: center;

    border: 1px solid #ddd;

    margin-bottom: 15px;

}

.aqi-number {

    font-size: 42px;

    font-weight: 700;

}

.aqi-label {

    font-size: 18px;

    font-weight: 600;

}

</style>
""", unsafe_allow_html=True)


# =================================================================
# CONFIGURATION
# =================================================================

CSV_FILE = "aqi_ml_ready.csv"

FLASK_URL = "http://127.0.0.1:5000"


# =================================================================
# AQI CATEGORY
# =================================================================

def get_aqi_category(aqi):

    if aqi <= 50:

        return "Good"

    elif aqi <= 100:

        return "Moderate"

    elif aqi <= 150:

        return "Unhealthy for Sensitive Groups"

    elif aqi <= 200:

        return "Unhealthy"

    elif aqi <= 300:

        return "Very Unhealthy"

    else:

        return "Hazardous"


# =================================================================
# AQI STATUS
# =================================================================

def get_aqi_status(aqi):

    if aqi <= 50:

        return "🟢"

    elif aqi <= 100:

        return "🟡"

    elif aqi <= 150:

        return "🟠"

    elif aqi <= 200:

        return "🔴"

    elif aqi <= 300:

        return "🟣"

    else:

        return "⚫"


# =================================================================
# LOAD DATA
# =================================================================

@st.cache_data

def load_data():

    data = pd.read_csv(
        CSV_FILE
    )

    if "timestamp" in data.columns:

        data["timestamp"] = pd.to_datetime(
            data["timestamp"],
            errors="coerce"
        )

        data = data.sort_values(
            "timestamp"
        )

    return data


df = load_data()


# =================================================================
# HEADER
# =================================================================

st.markdown(
    '<div class="main-title">🌍 Pearls AQI Predictor</div>',
    unsafe_allow_html=True
)

st.markdown(
    '<div class="subtitle">'
    'Air Quality Index Forecasting System'
    '</div>',
    unsafe_allow_html=True
)


# =================================================================
# SIDEBAR
# =================================================================

st.sidebar.title("⚙️ Dashboard")

st.sidebar.markdown(
    "### Project"
)

st.sidebar.write(
    "Pearls AQI Predictor"
)

st.sidebar.markdown(
    "### Forecast Horizons"
)

st.sidebar.write(
    "• 24 Hours\n"
    "• 48 Hours\n"
    "• 72 Hours"
)


# =================================================================
# CITY SELECTION
# =================================================================

if "city" in df.columns:

    cities = sorted(
        df["city"]
        .dropna()
        .astype(str)
        .unique()
        .tolist()
    )

else:

    cities = ["Lahore"]


selected_city = st.sidebar.selectbox(
    "Select City",
    cities
)


city_df = df[
    df["city"].astype(str) == selected_city
].copy()


if len(city_df) == 0:

    city_df = df.copy()


latest = city_df.iloc[-1]


# =================================================================
# CURRENT AQI
# =================================================================

st.markdown("## 📊 Current Air Quality")


# Use API AQI when available
if "api_aqi" in latest:

    current_aqi = float(
        latest["api_aqi"]
    )

elif "AQI" in latest:

    current_aqi = float(
        latest["AQI"]
    )

else:

    current_aqi = 0.0


category = get_aqi_category(
    current_aqi
)

status_icon = get_aqi_status(
    current_aqi
)


col1, col2, col3, col4 = st.columns(4)


with col1:

    st.metric(
        "Current AQI",
        f"{current_aqi:.2f}"
    )


with col2:

    st.metric(
        "Status",
        f"{status_icon} {category}"
    )


with col3:

    if "PM2_5" in latest:

        st.metric(
            "PM2.5",
            f"{float(latest['PM2_5']):.2f}"
        )

    else:

        st.metric(
            "PM2.5",
            "N/A"
        )


with col4:

    if "PM10" in latest:

        st.metric(
            "PM10",
            f"{float(latest['PM10']):.2f}"
        )

    else:

        st.metric(
            "PM10",
            "N/A"
        )


# =================================================================
# DATE / TIME
# =================================================================

if "timestamp" in latest:

    st.caption(
        f"Latest observation: {latest['timestamp']}"
    )


# =================================================================
# FORECAST
# =================================================================

st.markdown("## 🔮 AQI Forecast")


# =================================================================
# FEATURES
# =================================================================

FEATURES = [

    "PM2_5",
    "PM10",
    "CO",
    "NO2",
    "SO2",
    "O3",
    "NH3",

    "hour",
    "day",
    "month",
    "weekday",
    "is_weekend",

    "AQI_lag_1",
    "AQI_lag_3",
    "AQI_lag_6",
    "AQI_lag_12",
    "AQI_lag_24",

    "AQI_change",
    "AQI_change_rate",

    "AQI_rolling_mean_3",
    "AQI_rolling_mean_6",
    "AQI_rolling_std_6"

]


# =================================================================
# CREATE INPUT
# =================================================================

feature_data = {}


missing_features = []


for feature in FEATURES:

    if feature in latest:

        value = latest[feature]

        try:

            feature_data[feature] = float(value)

        except:

            feature_data[feature] = 0.0

    else:

        missing_features.append(
            feature
        )


# =================================================================
# GET PREDICTIONS
# =================================================================

predictions = {}


api_error = None


if len(missing_features) == 0:

    payload = feature_data.copy()

    payload["city"] = selected_city


    try:

        response = requests.post(

            f"{FLASK_URL}/predict",

            json=payload,

            timeout=10

        )


        if response.status_code == 200:

            result = response.json()

            predictions = result.get(
                "predictions",
                {}
            )

        else:

            api_error = (
                f"API returned HTTP "
                f"{response.status_code}"
            )


    except Exception as e:

        api_error = str(e)


else:

    api_error = (
        "Missing features: "
        + ", ".join(missing_features)
    )


# =================================================================
# DISPLAY FORECAST CARDS
# =================================================================

c1, c2, c3 = st.columns(3)


horizons = [
    ("24h", c1, "24 Hours"),
    ("48h", c2, "48 Hours"),
    ("72h", c3, "72 Hours")
]


forecast_values = []


for key, column, label in horizons:

    with column:

        if key in predictions:

            value = float(
                predictions[key].get(
                    "aqi",
                    predictions[key].get(
                        "predicted_AQI",
                        0
                    )
                )
            )

            cat = predictions[key].get(
                "category",
                get_aqi_category(value)
            )

            forecast_values.append(
                value
            )

            st.metric(
                label,
                f"{value:.2f}"
            )

            st.write(
                f"{get_aqi_status(value)} {cat}"
            )

        else:

            st.metric(
                label,
                "N/A"
            )


if api_error:

    st.warning(
        "Prediction API issue: "
        + api_error
    )


# =================================================================
# FORECAST CHART
# =================================================================

if len(forecast_values) == 3:

    forecast_df = pd.DataFrame({

        "Forecast": [
            "24 Hours",
            "48 Hours",
            "72 Hours"
        ],

        "AQI": forecast_values

    })


    fig = px.line(

        forecast_df,

        x="Forecast",

        y="AQI",

        markers=True,

        title="AQI Forecast — Next 3 Days"

    )


    fig.update_layout(
        height=400,
        xaxis_title="Forecast Horizon",
        yaxis_title="AQI"
    )


    st.plotly_chart(
        fig,
        use_container_width=True
    )


# =================================================================
# ALERT SYSTEM
# =================================================================

if len(forecast_values) > 0:

    maximum_forecast = max(
        forecast_values
    )


    if maximum_forecast > 300:

        st.error(
            "🚨 HAZARDOUS AQI ALERT — "
            "Air quality is expected to reach hazardous levels."
        )

    elif maximum_forecast > 200:

        st.error(
            "⚠️ VERY UNHEALTHY AQI ALERT"
        )

    elif maximum_forecast > 150:

        st.warning(
            "⚠️ UNHEALTHY AQI FORECAST"
        )

    elif maximum_forecast > 100:

        st.warning(
            "⚠️ AQI may become unhealthy for sensitive groups."
        )

    else:

        st.success(
            "✓ Forecast AQI remains within the Good/Moderate range."
        )


# =================================================================
# HISTORICAL AQI
# =================================================================

st.markdown("## 📈 Historical Air Quality")


if "timestamp" in city_df.columns:

    historical = city_df.copy()


    if "api_aqi" in historical.columns:

        aqi_column = "api_aqi"

    elif "AQI" in historical.columns:

        aqi_column = "AQI"

    else:

        aqi_column = None


    if aqi_column:

        historical[aqi_column] = pd.to_numeric(
            historical[aqi_column],
            errors="coerce"
        )


        historical = historical.dropna(
            subset=[aqi_column]
        )


        # Last 72 observations

        historical = historical.tail(
            72
        )


        fig_history = px.line(

            historical,

            x="timestamp",

            y=aqi_column,

            markers=True,

            title="Recent AQI History"

        )


        fig_history.update_layout(
            height=450,
            xaxis_title="Time",
            yaxis_title="AQI"
        )


        st.plotly_chart(
            fig_history,
            use_container_width=True
        )


# =================================================================
# POLLUTANT SECTION
# =================================================================

st.markdown("## 🧪 Pollutant Measurements")


pollutants = [

    ("PM2_5", "PM2.5"),

    ("PM10", "PM10"),

    ("CO", "CO"),

    ("NO2", "NO₂"),

    ("SO2", "SO₂"),

    ("O3", "O₃"),

    ("NH3", "NH₃")

]


available_pollutants = []


for column_name, display_name in pollutants:

    if column_name in latest:

        try:

            value = float(
                latest[column_name]
            )

            available_pollutants.append(
                (display_name, value)
            )

        except:

            pass


if available_pollutants:

    pollutant_columns = st.columns(
        len(available_pollutants)
    )


    for i, (name, value) in enumerate(
        available_pollutants
    ):

        with pollutant_columns[i]:

            st.metric(
                name,
                f"{value:.2f}"
            )


# =================================================================
# WEATHER SECTION
# =================================================================

st.markdown("## 🌤️ Weather Conditions")


weather_data = []


weather_features = [

    ("temperature", "Temperature", "°C"),

    ("feels_like", "Feels Like", "°C"),

    ("humidity", "Humidity", "%"),

    ("pressure", "Pressure", "hPa"),

    ("wind_speed", "Wind Speed", "m/s"),

    ("clouds", "Clouds", "%")

]


for column_name, name, unit in weather_features:

    if column_name in latest:

        try:

            value = float(
                latest[column_name]
            )

            weather_data.append(
                (name, value, unit)
            )

        except:

            pass


if weather_data:

    weather_columns = st.columns(
        min(
            len(weather_data),
            4
        )
    )


    for i, (name, value, unit) in enumerate(
        weather_data
    ):

        with weather_columns[
            i % len(weather_columns)
        ]:

            st.metric(
                name,
                f"{value:.2f} {unit}"
            )


# =================================================================
# MODEL INFORMATION
# =================================================================

st.markdown("## 🤖 Model Information")


model_col1, model_col2, model_col3 = st.columns(3)


with model_col1:

    st.info(
        """
        **24-Hour Model**

        Random Forest

        Forecast: 24 hours
        """
    )


with model_col2:

    st.info(
        """
        **48-Hour Model**

        Random Forest

        Forecast: 48 hours
        """
    )


with model_col3:

    st.info(
        """
        **72-Hour Model**

        Random Forest

        Forecast: 72 hours
        """
    )


# =================================================================
# MODEL PERFORMANCE
# =================================================================

st.markdown("## 📊 Model Performance")


performance = pd.DataFrame({

    "Forecast": [
        "24 Hours",
        "48 Hours",
        "72 Hours"
    ],

    "Model": [
        "Random Forest",
        "Random Forest",
        "Random Forest"
    ],

    "MAE": [
        0.372651,
        0.488431,
        0.477965
    ],

    "RMSE": [
        0.596471,
        0.660589,
        0.599502
    ],

    "R²": [
        -0.540329,
        -0.889284,
        -0.465493
    ]

})


st.dataframe(
    performance,
    use_container_width=True,
    hide_index=True
)


st.caption(
    "Note: The current Module 7 evaluation reported negative R² values. "
    "These models should be improved before production deployment."
)


# =================================================================
# DATASET INFORMATION
# =================================================================

st.markdown("## 📁 Dataset Information")


info1, info2, info3 = st.columns(3)


with info1:

    st.metric(
        "Dataset Rows",
        len(df)
    )


with info2:

    st.metric(
        "Dataset Columns",
        len(df.columns)
    )


with info3:

    st.metric(
        "Selected City",
        selected_city
    )


# =================================================================
# API STATUS
# =================================================================

st.markdown("## 🔌 API Status")


try:

    health_response = requests.get(

        f"{FLASK_URL}/health",

        timeout=5

    )


    if health_response.status_code == 200:

        st.success(
            "✓ Flask Prediction API is healthy"
        )

        st.json(
            health_response.json()
        )

    else:

        st.error(
            "Flask API returned an error."
        )


except Exception as e:

    st.error(
        f"Flask API unavailable: {e}"
    )


# =================================================================
# FOOTER
# =================================================================

st.markdown("---")

st.markdown(
    """
    <div style="text-align:center">

    **Pearls AQI Predictor**

    Machine Learning Air Quality Forecasting System

    Python • Scikit-learn • Flask • Streamlit

    Forecast Horizons: 24h • 48h • 72h

    </div>
    """,
    unsafe_allow_html=True
)
